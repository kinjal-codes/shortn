import React, { Component } from 'react';

export default class ListUrl extends Component {
  render() {
    return (
      <div>
        <p>You are on the Exercises List component!</p>
      </div>
    )
  }
}