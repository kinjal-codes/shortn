import React, { Component } from 'react';

export default class EditUrl extends Component {
  render() {
    return (
      <div>
        <p>You are on the Edit component!</p>
      </div>
    )
  }
}