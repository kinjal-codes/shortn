import React, { Component } from 'react';

export default class Navbar extends Component {
  render() {
    return (
      <div>
        <p>You are on the Navbar!</p>
      </div>
    )
  }
}