import React, { Component } from 'react';
import axios from 'axios';

export default class CreateUrl extends Component {

  constructor(props) {
    super(props);
    this.state = {
      sourceUrl: ''
    }
    this.handleInputChange = this.handleInputChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  handleInputChange(event) {
    const target = event.target;
    const value = target.type === 'checkbox' ? target.checked : target.value;
    const name = target.name;

    this.setState({
      [name]: value
    });
  }

  onSubmit(e) {
    e.preventDefault();
    const newUrl = {
      sourceUrl : this.state.sourceUrl
    };
    console.log("newUrl:",newUrl);
    axios.post('http://localhost:5000/add', newUrl)
    .then(res => console.log(res.data));
  }

  render() {
    return (
      <div>
        <form onSubmit={this.onSubmit}>
          <div className="form-group"> 
            <label>URL: </label>
            <input  type="text" name="sourceUrl"
                required
                className="form-control"
                value={this.state.sourceUrl}
                onChange={this.handleInputChange}
                />
          </div>
          <div className="form-group">
            <input type="submit" value="Shorten" className="btn btn-primary" />
          </div>
        </form>
      </div>
    )
  }
}